

function call_rivers()
{


    var river = L.river(rio, {
    minWidth: 4,  // px
    maxWidth: 4,
    color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_2, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
     color: "#29439c",  // px
}).addTo(mymap);

var river = L.river(rio_4, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
     color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_5, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_6, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_7, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_8, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);

var river = L.river(rio_9, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_10, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);


var river = L.river(rio_11, {
    minWidth: 4,  // px
    maxWidth: 4 , // px
    color: "#29439c",  // px
}).addTo(mymap);



var river = L.river(quebrada, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_1, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_2, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_3, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_4, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_5, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_6, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_7, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_8, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_9, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_10, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_11, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_12, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_13, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_14, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_15, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_16, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_17, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_18, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_19, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_20, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_21, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_22, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_23, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_24, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_25, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_26, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_27, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_28, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_29, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_30, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_31, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_32, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_33, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_34, {
    minWidth: 4,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_35, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_36, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_37, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_38, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_39, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_40, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_41, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_42, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_43, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_44, {
    minWidth: 4,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_45, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_46, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_47, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_48, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_49, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_50, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_51, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_52, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_53, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_54, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_55, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_56, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_57, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_58, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_59, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_60, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_61, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_62, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_63, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_64, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_65, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_66, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_67, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_68, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_69, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_70, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_71, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_72, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_73, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_74, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_75, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_76, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_77, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_78, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_79, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_80, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_81, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_82, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_83, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_84, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_85, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_86, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_87, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_88, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_89, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_90, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_91, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_92, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_93, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_94, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_95, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_96, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_97, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);



var river = L.river(quebrada_98, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_99, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_100, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_101, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_102, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_103, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_104, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_105, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_106, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_107, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_108, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_109, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_110, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_111, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_112, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_113, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_114, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_115, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_116, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_117, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_118, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_119, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_120, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_121, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_122, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_123, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_124, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_125, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_126, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_127, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_128, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_129, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_130, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_131, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_132, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_133, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_134, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_135, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_136, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_137, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_138, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_139, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_140, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_141, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_142, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_143, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_144, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_145, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_146, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_147, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
var river = L.river(quebrada_148, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_149, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_150, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_151, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_152, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_153, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_154, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_155, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);

var river = L.river(quebrada_156, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_157, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);


var river = L.river(quebrada_158, {
    minWidth: 2,  // px
    maxWidth: 2 , // px
    color: "#a4ebf3",  // px
}).addTo(mymap);
}



